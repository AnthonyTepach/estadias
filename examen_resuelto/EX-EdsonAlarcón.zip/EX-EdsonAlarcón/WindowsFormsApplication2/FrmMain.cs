﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class FrmMain : Form
    {
        string cs = @"Data Source=localhost;Initial Catalog=prueba;Integrated Security=True";
        public FrmMain(string cliente)
        {
            
            InitializeComponent();
            cargargrid1();
            cargargrid2();
            llenarCliente(cliente);
            bloquear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin fl = new frmLogin();
            fl.Show();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet.clientes' Puede moverla o quitarla según sea necesario.
            this.clientesTableAdapter.Fill(this.pruebaDataSet.clientes);
            cmbClientes.DataSource = Cargar();
    cmbClientes.DisplayMember = "nombre";
    cmbClientes.ValueMember = "idcliente";

        }
        private void cargargrid1()
        {
            SqlConnection Con = new SqlConnection(cs);
            SqlCommand Com;
            SqlDataAdapter Adp;
            DataTable datos = new DataTable("x");

            Con.Open();
            Com = new SqlCommand();
            Com.Connection = Con;
            Com.CommandType = CommandType.Text;
            Com.CommandText = "Select fecha,clientes.nombre,cantidad, precio From clientes inner join registrocompras on clientes.idcliente=registrocompras.idcliente inner join detallecompra on detallecompra.idregistrocompra=registrocompras.idregistrocompra inner join productos p on p.idproducto=detallecompra.idproducto";

            Adp = new SqlDataAdapter();
            Adp.SelectCommand = Com;
            Adp.Fill(datos);

            foreach (DataRow r in datos.Rows)
            {
                dataGridView1.Rows.Add(r.ItemArray); // Esto es en el caso que sea igual la tabla con tu diseño del datagridview
                dataGridView1.Rows.Add(r[0], r[1], r[2], r[3]);
            }

        }
        private void cargargrid2()
        {
            SqlConnection Con = new SqlConnection(cs);
            SqlCommand Com;
            SqlDataAdapter Adp;
            DataTable datos = new DataTable("x");

            Con.Open();
            Com = new SqlCommand();
            Com.Connection = Con;
            Com.CommandType = CommandType.Text;
            Com.CommandText = "Select nombre,preciodia,descuento from productos inner join detallecompra on productos.idproducto=detallecompra.idproducto ";

            Adp = new SqlDataAdapter();
            Adp.SelectCommand = Com;
            Adp.Fill(datos);

            foreach (DataRow r in datos.Rows)
            {
                dataGridView2.Rows.Add(false,r[0],"", r[1], "");
            }

        }
        private void llenarCliente(string cliente){
            
        }
        private void bloquear()
        {
            dateTimePicker1.Enabled = false;
            cmbClientes.Enabled = false;
            btnAceptar.Enabled = false;
            btnCancelar.Enabled = false;
            btnCalcular.Enabled = false;
            txtCantidad.Enabled = false;
            txtTotal.Enabled = false;
            btnEditar.Enabled = false;
            txtBuscar.Enabled = false;
            
        }

        private DataTable Cargar()
{
    SqlConnection Con = new SqlConnection(cs);
        {
                DataTable dt = new DataTable();
                string query = "SELECT * FROM clientes";
                SqlCommand cmd = new SqlCommand(query, Con);
                SqlDataAdapter adap = new SqlDataAdapter(cmd);
                adap.Fill(dt);
                return dt;
        }
}

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            btnAceptar.Enabled = true;
            btnCancelar.Enabled = true;
            btnAgregar.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnBuscar.Enabled = false;
            txtBuscar.Enabled = true;
            dateTimePicker1.Enabled = true;
            cmbClientes.Enabled = true;
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView2_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
        }

        private void dataGridView2_KeyPress(object sender, KeyPressEventArgs e)
        {
            int column = dataGridView2.CurrentCellAddress.X;
            int row = dataGridView2.CurrentCellAddress.Y;

            //Gets the value that existings in that cell
            string test = dataGridView2[column, row].EditedFormattedValue.ToString();
            txtBuscar.Text = test;
        }

    }
}
