﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EX_ROSA_ELIZABETH_ESPARZA
{
    public partial class Registro_de_compras : Form
    {
        public Registro_de_compras()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Registro_de_compras_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet5.DetalleCompra' Puede moverla o quitarla según sea necesario.
            this.detalleCompraTableAdapter2.Fill(this.pruebaDataSet5.DetalleCompra);
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet5.clientes' Puede moverla o quitarla según sea necesario.
            this.clientesTableAdapter1.Fill(this.pruebaDataSet5.clientes);
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet4.DetalleCompra' Puede moverla o quitarla según sea necesario.
            this.detalleCompraTableAdapter1.Fill(this.pruebaDataSet4.DetalleCompra);
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet.DetalleCompra' Puede moverla o quitarla según sea necesario.
            this.detalleCompraTableAdapter.Fill(this.pruebaDataSet.DetalleCompra);
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet.Productos' Puede moverla o quitarla según sea necesario.
            this.productosTableAdapter.Fill(this.pruebaDataSet.Productos);
            // TODO: esta línea de código carga datos en la tabla 'pruebaDataSet.clientes' Puede moverla o quitarla según sea necesario.
            this.clientesTableAdapter.Fill(this.pruebaDataSet.clientes);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
