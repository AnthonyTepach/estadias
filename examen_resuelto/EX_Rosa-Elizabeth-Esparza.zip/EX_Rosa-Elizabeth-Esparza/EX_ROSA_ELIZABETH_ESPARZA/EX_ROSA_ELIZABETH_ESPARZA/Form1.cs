﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace EX_ROSA_ELIZABETH_ESPARZA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public Boolean ValidaUsuarios()
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("El usuario no debe quedar vacio");
                return false;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("La contraseña no debe quedar vacia");
                return false;
            }
            else
                return true;

        }


        private void button1_Click(object sender, EventArgs e)
        {
            //AQUI VA EL CODIGO DE AUTENTIFICACION
            // login
            Boolean valido;
            valido = ValidaUsuarios();
            if (valido == true)
            {
                if (textBox1.Text == "Administrador" && textBox2.Text == "Admin")
                {
                    Hide();
                    Form1 A = new Form1();
                    A.ShowDialog();
                }

                Boolean aceptado = false;
                //aqui creamos la cadena de conexiom con los parametros para devolvere la misma
                String datasource = @"Data Source=(PAO-PC\SQLEXPRESS);
                        Initial Catalog=Prueba;
                        Integrated Security=True;";
                //aqui utilizamos el objeto SqlConnection para establecer conexion con sql
                SqlConnection conexion = new SqlConnection(datasource);

                //aqui utilizamos el objeto sqlCommand para ejecutar una consulta de sql pero desde visual studio
                SqlCommand consulta = new SqlCommand("select * from USUARIOS where nombre='" + textBox1.Text + "' and contraseña='" + textBox2.Text + "'", conexion);

                //aqui abrimos la conexion
                conexion.Open();

                //aqui utilizamos un objeto SqlDataReader para que pueda leer la bd y 
                //ejecute la consulta devolviendo un resultado
                SqlDataReader leerbd = consulta.ExecuteReader();

                if (leerbd.Read() == true)
                {
                    aceptado = true;
                }
                else
                {
                    aceptado = false;
                }

                if (aceptado == true)
                {
                    Hide();
                    Registro_de_compras su = new Registro_de_compras();
                    su.ShowDialog();

                }
                else
                {
                    MessageBox.Show("ACCESO DENEGADO");
                }
                conexion.Close();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}

