CREATE TABLE [dbo].[RegistroCompras](
	[IdRegistroCompras] [int] IDENTITY(1,1) NOT NULL,
	[fecha] [varchar](30) NULL,
	[idcliente] [varchar](40) NULL,
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[clientes](
	[idCliente] [int] IDENTITY(1,1) NOT NULL,
	[nombre] [varchar](80) NULL,
	
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[DetalleCompra](
	[IdDetalleCompra] [int] IDENTITY(1,1) NOT NULL,
	[idRegistroCompra] [int] NULL,
	[idProducto] [int] NULL,
	[cantidad] [int] NULL,
	[PrecioDia] [decimal](18,5) NULL,
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[Productos](
	[idProducto] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [varchar] NULL,
	[Precio] [decimal](18,5) NULL,
	[Descuento] [int] NULL,
	[LimiteDescuento] [varchar] NULL,
) ON [PRIMARY]

GO