﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//LIBRERIAS: CONEXION
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace Examen
{

    class Conexiones
    {
        //Objetos: Conexion
        SqlConnection conexion_a_SQL; //Alamacena Conexion
        SqlCommand comando_para_SQL; //Almacena Comando
        SqlDataReader dr;
        SqlDataAdapter da;
        DataTable dt;

        public Conexiones() //Metodo Principal Clase 
        {
            try
            {
                //Inicializamos el objeto y le damos valor
                conexion_a_SQL = new SqlConnection(@"Data Source=ANDRES;
                                                    Initial Catalog=practica;
                                                    Integrated Security=True;");
                //Abrir conexion
                conexion_a_SQL.Open();
            }
            catch (Exception Ex)
            {
                //Mensaje de error de conexion
                MessageBox.Show("Erro de conexión: " + Ex.ToString());
            }
        }
        //Metodo para Refrescar Tabla
        public void refrescarUsuario(DataGridView dGv1)
        {
            try
            {
                da = new SqlDataAdapter("Select RegistroCompras.Fecha, Clientes.nombre, DetalleCompra.Cantidad, DetalleCompra.PrecioDia from RegistroCompras, Clientes, DetalleCompra", conexion_a_SQL);
                dt = new DataTable();
                da.Fill(dt);
                dGv1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo llenar el Datagridview: " + ex.ToString());
            }
        }

        //Método para llenar combo cliente
        public void LlenarComboCliente(ComboBox cmb1)
        {
            SqlConnection conexion = new SqlConnection();
            conexion.ConnectionString = @"Data Source=ANDRES;Initial Catalog =practica;Integrated Security=True";
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter("SELECT nombre FROM Clientes WHERE nombre=nombre", conexion);
            da.Fill(ds, "EMPLEADO");
            cmb1.DataSource = ds.Tables[0].DefaultView;
            //Aquí se especifíca el campo de la tabla
            cmb1.ValueMember = "NOMBRE";
            cmb1.Text = "Seleccione al empleado:";
        }
    }

}