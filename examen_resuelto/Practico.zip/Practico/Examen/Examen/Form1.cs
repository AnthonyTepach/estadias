﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace Examen
{
    public partial class Form1 : Form

    {
        Conexiones Conexion = new Conexiones();
        public Form1()
        {

            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Conexion.refrescarUsuario(dgv1);
            btnEditar.Enabled = false;
            btnAceptar.Enabled = false;
            btnCancelar.Enabled = false;
            btnCalcular.Enabled = false; 
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            btnEditar.Enabled = true;
            SqlConnection conexion = new SqlConnection();
            conexion.ConnectionString = @"Data Source=ANDRES;Initial Catalog =practica;Integrated Security=True";
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter("SELECT nombre FROM Clientes WHERE nombre=nombre", conexion);
            da.Fill(ds, "EMPLEADO");
            cmb1.DataSource = ds.Tables[0].DefaultView;
            //Aquí se especifíca el campo de la tabla
            cmb1.ValueMember = "NOMBRE";
            cmb1.Text = "Seleccione al cliente:";
            btnAceptar.Enabled = true;
            btnCancelar.Enabled = true;
            textBox1.Enabled = false;

        }

        
    }
}
