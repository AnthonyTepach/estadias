﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prueba
{
    public partial class Registro_de_Compra : Form
    {
        conexion Conexion = new conexion(); 

        public Registro_de_Compra()
        {
           
            InitializeComponent();

        }

        private void Registro_de_Compra_Load(object sender, EventArgs e)
        {
            Conexion.DATA(DataGridView1); 
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnAceptar.Enabled = false;
            btnCancelar.Enabled = false; 

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
