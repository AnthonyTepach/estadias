﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace prueba
{

    class conexion
    {
       
        SqlConnection Conexion;
        SqlCommand comando_para_SQL;
        SqlDataReader dr;
        SqlDataAdapter da;
        DataTable dt;

        public conexion() //main class 
        {
            try
            {

                Conexion = new SqlConnection(@"Data Source=GIRON-PC\SQLEXPRESS; 
                                                    Initial Catalog=PRUEBA;
                                                    Integrated Security=True;");
                                 //conexion SQL


                Conexion.Open();
            }
            catch (Exception Ex)
            {
              
                MessageBox.Show("Verifica tu Conexión: " + Ex.ToString());
            }
        }

        public void DATA(DataGridView DataGridView1)
        {
            try
            {
                da = new SqlDataAdapter("Select RegistroCompra.Fecha, Cliente.nombre, DetalleCompra.Cantidad, DetalleCompra.PrecioDia from RegistroCompra, Cliente, DetalleCompra", Conexion);
                dt = new DataTable();
                da.Fill(dt);
                DataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Revisa Datagridview: " + ex.ToString());
            }
        }
    }

}